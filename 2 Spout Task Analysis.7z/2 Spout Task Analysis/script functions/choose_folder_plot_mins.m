function [first_peaks, first_mean, second_peaks, second_mean, p] = choose_folder_plot_mins()
    fps = 20; 
    time_window = 9;
    left_shift_window = 0; %shift 1 second left
    z_right_trials = [];
    z_left_trials = [];
    right_dFF_trials = [];
    left_dFF_trials = [];
    corrected_left_z_scores = [];
    corrected_right_z_scores = [];
    left_US_target_frame = [];
    right_US_target_frame = [];
    US_target_frame = [];
    
    disp('Select first file to compare (can check dFF or z score)');
    
    [file, path] = uigetfile('.mat');
    load(horzcat(path, file));
    
    if ~isempty(US_target_frame)
        first_US_target_frame = US_target_frame;
    elseif ~isempty(left_US_target_frame)
        first_US_target_frame = left_US_target_frame;
    elseif ~isempty(right_US_target_frame)
        first_US_target_frame = right_US_target_frame;
    end
    
    if ~isempty(corrected_left_z_scores)
        first_trials = corrected_left_z_scores;
    elseif ~isempty(corrected_right_z_scores)
        first_trials = corrected_right_z_scores;
    elseif ~isempty(z_left_trials)
        first_trials = z_left_trials;
    elseif ~isempty(z_right_trials)
        first_trials = z_right_trials;
    elseif ~isempty(right_dFF_trials)
        first_trials = right_dFF_trials;
    elseif ~isempty(left_dFF_trials)
        first_trials = left_dFF_trials;
    end
    first_path = horzcat(path, file);
    
    slashes = strfind(path, '/');
    if contains(file, 'right')
        first_side = 'right';
    elseif contains(file, 'left')
        first_side = 'left';
    elseif contains(path, 'left')
        first_side = 'left';
    elseif contains(path, 'right')  
        first_side = 'right';
    end
    
    if contains(path, 'artifacts')
        add_ind = 1;
    else
        add_ind = 0;
    end
    
    first_name = path((slashes(end - 2 - add_ind) + 1):(slashes(end - 1 - add_ind) - 1));
    disp(horzcat('Loading ', first_side, ' ', first_name, ' data...'))
    
    
    %% now do second
    z_right_trials = [];
    z_left_trials = [];
    corrected_left_z_scores = [];
    corrected_right_z_scores = [];
    right_dFF_trials = [];
    left_dFF_trials = [];
    left_US_target_frame = [];
    right_US_target_frame = [];
    US_target_frame = [];
    disp('Select second folder to compare (can check dFF or z score)');
    
    [file, path] = uigetfile('.mat');
    load(horzcat(path, file));
    if ~isempty(US_target_frame)
        second_US_target_frame = US_target_frame;
    elseif ~isempty(left_US_target_frame)
        second_US_target_frame = left_US_target_frame;
    elseif ~isempty(right_US_target_frame)
        second_US_target_frame = right_US_target_frame;
    end
    
    if ~isempty(corrected_left_z_scores)
        second_trials = corrected_left_z_scores;
    elseif ~isempty(corrected_right_z_scores)
        second_trials = corrected_right_z_scores;
    elseif ~isempty(z_left_trials)
        second_trials = z_left_trials;
    elseif ~isempty(z_right_trials)
        second_trials = z_right_trials;
    elseif ~isempty(right_dFF_trials)
        second_trials = right_dFF_trials;
    elseif ~isempty(left_dFF_trials)
        second_trials = left_dFF_trials;
    end
    second_path = horzcat(path, file);
    
    slashes = strfind(path, '/');
    if contains(file, 'right')
        second_side = 'right';
    elseif contains(file, 'left')
        second_side = 'left';
    elseif contains(path, 'left')
        second_side = 'left';
    elseif contains(path, 'right')  
        second_side = 'right';
    end
    
    if contains(path, 'artifacts')
        add_ind = 1;
    else
        add_ind = 0;
    end
    second_name = path((slashes(end - 2 - add_ind) + 1):(slashes(end - 1 - add_ind) - 1));
    disp(horzcat('Loading ', second_side, ' ', second_name, ' data...'))

    labels = {horzcat(first_side, ' ', first_name), horzcat(second_side, ' ', second_name)};
    %US_frame = US_target_frame;
    [first_peaks, first_mean, second_peaks, second_mean, p] = plot_mins(first_trials, second_trials, first_US_target_frame, second_US_target_frame, labels, time_window, fps, left_shift_window);
    current_dir = pwd;
    if ~exist('peak graphs', 'dir')
        mkdir('peak graphs');
    end
    if contains(first_path, 'z_scores')
        ylabel('Peak Z-Score(dF/F)', 'FontSize', 20);
        type = 'z_score';
    elseif contains(first_path, 'dFF')
        ylabel('Peak dF/F', 'FontSize', 20);
        type = 'dFF';
    end
    cd('peak graphs');
    comp_name = horzcat(first_name, ' ', first_side, ' vs ', second_name, ' ', second_side, ' ', type);
    backwards_name = horzcat(second_name, ' ', second_side, ' vs ', first_name, ' ', first_side, ' ', type);
    if and(~exist(horzcat(comp_name, '.mat'), 'file'), ~exist(horzcat(backwards_name, '.mat'), 'file'))
        save(horzcat(comp_name, '.mat'), 'p', 'first_peaks', 'first_mean', 'second_peaks', 'second_mean');
        savefig(comp_name);
        cd(current_dir);
    else
        disp('You have run this comparison before.')
        save(horzcat(comp_name, '.mat'), 'p', 'first_peaks', 'first_mean', 'second_peaks', 'second_mean');
        savefig(comp_name);
        cd(current_dir);
    end
    
end